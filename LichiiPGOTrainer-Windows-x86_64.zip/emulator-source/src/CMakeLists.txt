# SPDX-FileCopyrightText: Copyright 2026 Eden Emulator Project
# SPDX-License-Identifier: GPL-3.0-or-later

# SPDX-FileCopyrightText: 2018 yuzu Emulator Project
# SPDX-License-Identifier: GPL-2.0-or-later

# Enable modules to include each other's files
include_directories(.)

# Dynarmic
if ((ARCHITECTURE_x86_64 OR ARCHITECTURE_arm64 OR ARCHITECTURE_riscv64 OR ARCHITECTURE_loongarch64) AND NOT YUZU_STATIC_ROOM)
    add_subdirectory(dynarmic)
    add_library(dynarmic::dynarmic ALIAS dynarmic)
endif()

# CMake seems to only define _DEBUG on Windows
set_property(DIRECTORY APPEND PROPERTY
    COMPILE_DEFINITIONS $<$<CONFIG:Debug>:_DEBUG> $<$<NOT:$<CONFIG:Debug>>:NDEBUG>)

if (YUZU_STATIC_BUILD)
    add_compile_definitions(QT_STATICPLUGIN)
endif()

# Build identifiers
if (NIGHTLY_BUILD)
    add_compile_definitions(NIGHTLY_BUILD)
endif()

# Legacy (android only)
if (YUZU_LEGACY)
    message(WARNING "Making legacy build. Performance may suffer.")
    add_compile_definitions(YUZU_LEGACY)
endif()

# Genshin Spoof (android only)
if (GENSHIN_SPOOF)
    message(WARNING "Making Genshin spoof build")
    add_compile_definitions(GENSHIN_SPOOF)
endif()

# Build ID (mingw only right now)
# Pretty much just refers to the CI "target" for this build
if (NOT BUILD_ID)
    if (ARCHITECTURE_x86_64)
        set(BUILD_ID amd64)
    elseif(ARCHITECTURE_arm64)
        if (WIN32)
            set(BUILD_ID arm64)
        else()
            set(BUILD_ID aarch64)
        endif()
    else()
        set(BUILD_ID "${ARCHITECTURE}")
    endif()
endif()

add_compile_definitions(BUILD_ID="${BUILD_ID}")

# Set compilation flags
if (MSVC)
    # Avoid windows.h min/max macros with both cl.exe and clang-cl.
    add_compile_definitions(NOMINMAX)
endif()

if (MSVC AND NOT CXX_CLANG)
    set(CMAKE_CONFIGURATION_TYPES Debug Release CACHE STRING "" FORCE)

    # Silence "deprecation" warnings
    add_compile_definitions(_CRT_SECURE_NO_WARNINGS _CRT_NONSTDC_NO_DEPRECATE _SCL_SECURE_NO_WARNINGS)

    # Avoid windows.h from including some usually unused libs like winsocks.h, since this might cause some redefinition errors.
    add_compile_definitions(WIN32_LEAN_AND_MEAN)

    # Ensure that projects are built with Unicode support.
    add_compile_definitions(UNICODE _UNICODE)

    # /W4                 - Level 4 warnings
    # /MP                 - Multi-threaded compilation
    # /Zm                 - Specifies the precompiled header memory allocation limit
    # /Zo                 - Enhanced debug info for optimized builds
    # /permissive-        - Enables stricter C++ standards conformance checks
    # /EHsc               - C++-only exception handling semantics
    # /utf-8              - Set source and execution character sets to UTF-8
    # /volatile:iso       - Use strict standards-compliant volatile semantics.
    # /Zc:externConstexpr - Allow extern constexpr variables to have external linkage, like the standard mandates
    # /Zc:inline          - Let codegen omit inline functions in object files
    # /Zc:preprocessor    - Enable standards-conforming preprocessor
    # /Zc:throwingNew     - Let codegen assume `operator new` (without std::nothrow) will never return null
    # /GT                 - Supports fiber safety for data allocated using static thread-local storage
    add_compile_options(
        /MP
        /Zm200
        /Zo
        /permissive-
        /EHsc
        /std:c++20
        /utf-8
        /volatile:iso
        /Zc:externConstexpr
        /Zc:inline
        /Zc:preprocessor
        /Zc:throwingNew
        /GT

        # External headers diagnostics
        /external:anglebrackets # Treats all headers included by #include <header>, where the header file is enclosed in angle brackets (< >), as external headers
        /external:W0            # Sets the default warning level to 0 for external headers, effectively disabling warnings for them.

        /we4062 # Enumerator 'identifier' in a switch of enum 'enumeration' is not handled
        /we4189 # 'identifier': local variable is initialized but not referenced
        /we4265 # 'class': class has virtual functions, but destructor is not virtual
        /we4388 # 'expression': signed/unsigned mismatch
        /we4389 # 'operator': signed/unsigned mismatch
        /we4456 # Declaration of 'identifier' hides previous local declaration
        /we4457 # Declaration of 'identifier' hides function parameter
        /we4458 # Declaration of 'identifier' hides class member
        /we4459 # Declaration of 'identifier' hides global declaration
        /w44505 # 'function': unreferenced local function has been removed
        /we4547 # 'operator': operator before comma has no effect; expected operator with side-effect
        /we4549 # 'operator1': operator before comma has no effect; did you intend 'operator2'?
        /we4555 # Expression has no effect; expected expression with side-effect
        /we4826 # Conversion from 'type1' to 'type2' is sign-extended. This may cause unexpected runtime behavior.
        /we5038 # data member 'member1' will be initialized after data member 'member2'
        /we5233 # explicit lambda capture 'identifier' is not used
        /we5245 # 'function': unreferenced function with internal linkage has been removed

        /wd4100 # 'identifier': unreferenced formal parameter
        /wd4324 # 'struct_name': structure was padded due to __declspec(align())
        /wd4201 # nonstandard extension used : nameless struct/union
        /wd4702 # unreachable code (when used with LTO)

        $<$<CONFIG:Release>:/GS->   # No stack buffer overflow checks
        /Gy                         # Enable function level linking
        /GR-                        # Disable run time type information
    )

    if (NOT CXX_CLANG)
        add_compile_options(
            # Warnings
            /W4
            /WX-
        )
    endif()

    if (ARCHITECTURE_x86_64)
        add_compile_options(/QIntel-jcc-erratum)
    endif()

    set(CMAKE_EXE_LINKER_FLAGS_DEBUG   "/DEBUG /MANIFEST:NO" CACHE STRING "" FORCE)
    set(CMAKE_EXE_LINKER_FLAGS_RELEASE "/DEBUG /MANIFEST:NO /INCREMENTAL:NO /OPT:REF,ICF" CACHE STRING "" FORCE)
else()
    if (NOT MSVC)
        add_compile_options(
            $<$<COMPILE_LANGUAGE:C,CXX>:-fwrapv>
            $<$<COMPILE_LANGUAGE:C,CXX>:-pipe>
            # Disable RTTI (C++ only)
            $<$<COMPILE_LANGUAGE:CXX>:-fno-rtti>)
    endif()

    if (ENABLE_WERROR)
        add_compile_options(
            $<$<COMPILE_LANGUAGE:C,CXX>:-Werror=all>
            $<$<COMPILE_LANGUAGE:C,CXX>:-Werror=extra>
            $<$<COMPILE_LANGUAGE:C,CXX>:-Werror=missing-declarations>
            $<$<COMPILE_LANGUAGE:C,CXX>:-Werror=shadow>
            $<$<COMPILE_LANGUAGE:C,CXX>:-Werror=unused>)
    else()
        add_compile_options(
            $<$<COMPILE_LANGUAGE:C,CXX>:-Wall>
            $<$<COMPILE_LANGUAGE:C,CXX>:-Wextra>
            $<$<COMPILE_LANGUAGE:C,CXX>:-Wmissing-declarations>
            $<$<COMPILE_LANGUAGE:C,CXX>:-Wshadow>
            $<$<COMPILE_LANGUAGE:C,CXX>:-Wunused>
            # Some compilers could particularly misbehave :)
            $<$<COMPILE_LANGUAGE:C,CXX>:-Wno-error-all>)
    endif()
    add_compile_options(
        $<$<COMPILE_LANGUAGE:C,CXX>:-Wno-attributes>
        $<$<COMPILE_LANGUAGE:C,CXX>:-Wno-invalid-offsetof>
        $<$<COMPILE_LANGUAGE:C,CXX>:-Wno-unused-parameter>
        $<$<COMPILE_LANGUAGE:C,CXX>:-Wno-missing-field-initializers>)

    if (ENABLE_WERROR AND (NOT MSVC))
        add_compile_options(
            $<$<COMPILE_LANGUAGE:C,CXX>:-Wno-error=unused>
            $<$<COMPILE_LANGUAGE:C,CXX>:-Wno-error=unused-function>
        )
        endif()

    if (CXX_CLANG OR CXX_ICC OR CXX_APPLE) # Clang, AppleClang, or Intel C++
        if (NOT MSVC)
            add_compile_options(
                $<$<COMPILE_LANGUAGE:C,CXX>:-Wshadow-uncaptured-local>
                $<$<COMPILE_LANGUAGE:C,CXX>:-Wimplicit-fallthrough>
                $<$<COMPILE_LANGUAGE:C,CXX>:-Wtype-limits>)
        endif()
        add_compile_options(
            $<$<COMPILE_LANGUAGE:C,CXX>:-Wno-braced-scalar-init>
            $<$<COMPILE_LANGUAGE:C,CXX>:-Wno-unused-private-field>
            $<$<COMPILE_LANGUAGE:C,CXX>:-Wno-nullability-completeness>)
    endif()

    if (ARCHITECTURE_x86_64)
        add_compile_options($<$<COMPILE_LANGUAGE:C,CXX>:-mcx16>)
        if (LINUX OR FREEBSD)
            add_compile_options($<$<COMPILE_LANGUAGE:C,CXX>:-mtls-dialect=gnu2>)
        endif()
    endif()

    if (APPLE AND CXX_CLANG)
        add_compile_options($<$<COMPILE_LANGUAGE:C,CXX>:-stdlib=libc++>)
    endif()

    # GCC bugs
    if (CMAKE_CXX_COMPILER_VERSION VERSION_GREATER_EQUAL "11" AND CXX_GCC)
        # These diagnostics would be great if they worked, but are just completely broken
        # and produce bogus errors on external libraries like fmt.
        add_compile_options(
            $<$<COMPILE_LANGUAGE:C,CXX>:-Wno-array-bounds>
            $<$<COMPILE_LANGUAGE:C,CXX>:-Wno-stringop-overread>
            $<$<COMPILE_LANGUAGE:C,CXX>:-Wno-stringop-overflow>)
    endif()

    # GCC 13+ unswitches loops on switch statements and can drop cases from the unswitched copy
    # (same pass as https://gcc.gnu.org/PR128356). It dropped the split front's macro uploads
    # in Maxwell3D::FrontCallMultiMethod, so games using macros showed a black screen (#500).
    if (CMAKE_CXX_COMPILER_VERSION VERSION_GREATER_EQUAL "13" AND CXX_GCC)
        add_compile_options($<$<COMPILE_LANGUAGE:C,CXX>:-fno-unswitch-loops>)
    endif()

    # Set file offset size to 64 bits.
    #
    # On modern Unixes, this is typically already the case. The lone exception is
    # glibc, which may default to 32 bits. glibc allows this to be configured
    # by setting _FILE_OFFSET_BITS.
    if(CMAKE_SYSTEM_NAME STREQUAL "Linux" OR MINGW)
        add_compile_definitions(_FILE_OFFSET_BITS=64)
    endif()

    if (YUZU_STATIC_BUILD AND NOT APPLE AND NOT MSVC)
        add_compile_options(-static)

        # yuzu-cmd requires us to explicitly link libpthread, libgcc, and libstdc++ as static
        add_link_options(-Wl,-Bstatic -static -lpthread)
        add_link_options(-static-libgcc -static-libstdc++)
    endif()

    if (MINGW)
        add_compile_definitions(MINGW_HAS_SECURE_API)

        # Only windows has this requirement
        if (WIN32 AND ARCHITECTURE_x86_64)
            add_compile_options("-msse4.1")
        endif()
    endif()

    if(CMAKE_SYSTEM_NAME STREQUAL "Linux" OR MINGW)
        # GNU ar: Create thin archive files.
        # Requires binutils-2.19 or later.
        set(CMAKE_C_ARCHIVE_CREATE   "<CMAKE_AR> qcTP <TARGET> <LINK_FLAGS> <OBJECTS>")
        set(CMAKE_C_ARCHIVE_APPEND   "<CMAKE_AR> qTP  <TARGET> <LINK_FLAGS> <OBJECTS>")
        set(CMAKE_CXX_ARCHIVE_CREATE "<CMAKE_AR> qcTP <TARGET> <LINK_FLAGS> <OBJECTS>")
        set(CMAKE_CXX_ARCHIVE_APPEND "<CMAKE_AR> qTP  <TARGET> <LINK_FLAGS> <OBJECTS>")
    endif()
endif()

add_subdirectory(common)
add_subdirectory(network)

if (YUZU_ROOM)
    add_subdirectory(dedicated_room)
endif()

if (YUZU_ROOM_STANDALONE)
    add_subdirectory(yuzu_room_standalone)
    set_target_properties(yuzu-room PROPERTIES OUTPUT_NAME "eden-room")
endif()

if (YUZU_STATIC_ROOM)
    return()
endif()

add_subdirectory(core)
add_subdirectory(audio_core)
add_subdirectory(video_core)
add_subdirectory(hid_core)
add_subdirectory(input_common)
add_subdirectory(frontend_common)
add_subdirectory(shader_recompiler)

if (YUZU_TESTS)
    add_subdirectory(tests)
endif()

if (LICHII_FUZZERS)
    add_subdirectory(fuzz)
endif()

if (YUZU_CMD)
    add_subdirectory(yuzu_cmd)
    set_target_properties(yuzu-cmd PROPERTIES OUTPUT_NAME "eden-cli")
endif()

if (ENABLE_QT)
    add_subdirectory(qt_common)
    add_subdirectory(yuzu)
    if (WIN32 AND ENABLE_UPDATE_CHECKER)
        add_subdirectory(updater)
    endif()
endif()

if (ENABLE_WEB_SERVICE)
    add_subdirectory(web_service)
endif()

if (ANDROID)
    add_subdirectory(android/app/src/main/jni)
    target_include_directories(yuzu-android PRIVATE android/app/src/main)
endif()

include(GenerateDepHashes)
